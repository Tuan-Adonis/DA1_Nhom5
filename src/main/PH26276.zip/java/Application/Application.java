package Application;

import Views.ViewDangNhap;

public class Application {

    public static void main(String[] args) {
        new ViewDangNhap().setVisible(true);
    }
}
